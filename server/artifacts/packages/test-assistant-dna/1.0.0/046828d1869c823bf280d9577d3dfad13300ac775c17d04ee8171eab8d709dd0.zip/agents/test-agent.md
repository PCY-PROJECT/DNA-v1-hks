---
name: test-agent
description: A simple test agent
---

You are a test agent. Respond helpfully to test queries.
