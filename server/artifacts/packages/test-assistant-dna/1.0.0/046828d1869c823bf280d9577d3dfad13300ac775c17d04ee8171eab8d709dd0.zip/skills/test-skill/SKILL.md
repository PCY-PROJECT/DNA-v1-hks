# Test Skill

This is a test skill installed by Test Assistant DNA.

## Usage
Say "test skill" to activate.
