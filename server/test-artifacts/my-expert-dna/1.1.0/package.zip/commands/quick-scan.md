# /quick-scan — 快速漏洞扫描

## 用法

```
/quick-scan [合约文件路径 或 粘贴代码]
```

## 说明

聚焦 Critical 和 High 级别漏洞，快速（约 2–5 分钟）输出高危问题摘要，适合初步筛查和 CI/CD 集成。

## 执行步骤

1. 接收合约代码（无需额外上下文询问，直接开始扫描）
2. **只检查以下高危类别**（跳过 Medium / Low / Informational）：
   - 重入攻击（Reentrancy）
   - 无权限的关键函数（Missing Access Control）
   - 未初始化代理 / 代理升级无保护
   - 预言机操纵 / 闪电贷攻击面
   - 整数溢出（`unchecked` 块）
   - 直接资金提取风险（Rug Pull）
3. 输出精简报告（仅列出 Critical / High 发现，每条 3–5 行描述）
4. 若未发现 Critical / High，输出「初步扫描未发现高危问题，建议运行 /audit 进行完整审计」

## 输出格式

```
## 快速扫描结果 — {ContractName}

⚠️  发现 {n} 个 Critical，{n} 个 High 问题

### 🔴 [Critical] {漏洞标题}
- 位置：{file}:{line}
- 风险：{一句话说明}
- 建议：{一句话修复方向}

...

> 此为快速扫描结果，运行 /audit 获取完整报告和修复代码示例。
```
