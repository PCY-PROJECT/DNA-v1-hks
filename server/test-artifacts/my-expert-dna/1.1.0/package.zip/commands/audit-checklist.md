# /audit-checklist — 输出审计检查清单

## 用法

```
/audit-checklist [类别]
```

可选类别：`defi` / `nft` / `dao` / `proxy` / `bridge` / `token` / `all`（默认 `all`）

## 说明

输出指定场景的漏洞检查清单（Markdown 表格格式），可直接复制到审计文档或 GitHub Issue 中用于人工逐项确认。

## 执行步骤

1. 根据传入类别，从 SKILL.md 检查清单中筛选对应条目
2. 输出带 `[ ]` 勾选框的 Markdown 清单
3. 在清单末尾附注：「此清单基于 My Expert DNA v1.0.0，建议结合 Slither 自动扫描结果一同使用」

## 输出示例

```markdown
## DeFi 合约安全检查清单

### 预言机 / 价格操纵
- [ ] 是否使用 DEX 即时价格（spot price）作为唯一喂价
- [ ] Chainlink 是否检查 answeredInRound >= roundId
- [ ] TWAP 时间窗口是否足够长（≥ 30 分钟）
...
```
