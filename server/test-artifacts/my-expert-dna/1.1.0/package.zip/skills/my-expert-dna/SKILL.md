---
name: my-expert-dna
description: 智能合约安全审计专家，分析 Solidity/Vyper 合约中的漏洞、逻辑缺陷和安全风险，生成结构化审计报告。支持 EVM 兼容链、DeFi 协议、代理合约、治理合约等全场景审计。
triggers:
  - "审计合约"
  - "audit contract"
  - "合约安全"
  - "contract security"
  - "漏洞分析"
  - "vulnerability analysis"
  - "检查合约"
  - "review contract"
  - "安全审查"
  - "security review"
  - "合约审查"
  - "smart contract audit"
  - "审计报告"
  - "audit report"
  - "扫描漏洞"
  - "scan vulnerabilities"
  - "代码审计"
  - "快速扫描"
  - "quick scan"
  - "/audit"
  - "/quick-scan"
---

# My Expert DNA — 智能合约安全审计技能

## 触发场景

- 用户粘贴或上传 Solidity / Vyper 合约代码，要求安全检查
- 用户说「帮我审计这份合约」「这个合约有没有漏洞」
- 用户要求生成正式审计报告（`/audit`）
- 用户需要快速漏洞扫描（`/quick-scan`）
- 用户询问合约某段逻辑是否存在安全风险
- 用户准备部署合约前的安全检查

---

## 审计模式

### 模式一：完整审计（`/audit` 或默认）
全面逐函数检查，生成正式 Markdown 报告，含修复建议和代码示例。耗时较长，适合正式审计。

### 模式二：快速扫描（`/quick-scan`）
高危漏洞优先，5 分钟内输出 Critical / High 级别发现摘要，适合初步筛查。

---

## 执行流程

### Step 1 — 信息收集
- 确认合约完整源码（或文件路径）；若不完整，要求补充
- 了解合约用途（DeFi / NFT / DAO / Bridge / Token / Other）
- 了解目标部署链（Ethereum / BSC / Polygon / Arbitrum / 其他 EVM）
- 确认是否使用代理模式（Transparent / UUPS / Diamond）
- 了解已知的外部依赖（Chainlink Oracle / Uniswap / Aave 等）

### Step 2 — 静态分析
按以下分类逐项检查，记录每个发现的位置（文件:行号）。

### Step 3 — 风险评估
按 CVSS-like 标准分级，综合可利用性 × 影响范围打分。

### Step 4 — 报告生成
输出结构化 Markdown 报告，包含执行摘要、发现列表、修复建议、总体评分。

---

## 漏洞检查清单

### 1. 重入攻击（Reentrancy）[SWC-107]
- [ ] 外部调用前是否已更新状态变量（Checks-Effects-Interactions 模式）
- [ ] 是否使用 `ReentrancyGuard` 或等效保护
- [ ] 跨函数重入（`nonReentrant` 是否覆盖所有入口）
- [ ] 只读重入（view 函数中的状态一致性）
- [ ] ERC-777 / ERC-1155 回调引发的重入

### 2. 整数运算风险（Integer Issues）[SWC-101]
- [ ] Solidity < 0.8.0：是否使用 SafeMath 或等效防护
- [ ] Solidity ≥ 0.8.0：是否有 `unchecked` 块导致溢出
- [ ] 除法截断导致的精度损失
- [ ] 乘法运算顺序（先乘后除减少精度损失）
- [ ] 铸造/销毁操作的 supply 上限检查

### 3. 访问控制（Access Control）[SWC-105]
- [ ] 关键函数（mint / burn / pause / upgrade / withdraw）是否有权限保护
- [ ] `onlyOwner` 是否正确继承（Ownable 初始化）
- [ ] 角色权限是否最小化（RBAC 最小权限原则）
- [ ] 初始化函数（`initialize`）是否只能调用一次
- [ ] 时间锁（Timelock）是否用于高权限操作
- [ ] `tx.origin` 误用代替 `msg.sender` [SWC-115]

### 4. 未检查外部调用（Unchecked Calls）[SWC-104]
- [ ] `call` / `send` / `transfer` 返回值是否处理
- [ ] 低级 `call` 的 gas 限制
- [ ] 外部合约调用失败的回滚处理
- [ ] 批量操作中单个失败是否影响整体

### 5. 价格 / 预言机操纵（Oracle Manipulation）
- [ ] 是否使用 DEX 即时价格（spot price）作为唯一喂价
- [ ] Chainlink 是否检查 `answeredInRound >= roundId`（过时价格）
- [ ] Chainlink 是否检查 `updatedAt` 超时
- [ ] TWAP 时间窗口是否足够长（防闪电贷操纵）
- [ ] 多预言机聚合或备用预言机

### 6. 闪电贷攻击面（Flash Loan）
- [ ] 单区块内价格/余额可否被闪电贷操控
- [ ] 抵押品估值是否依赖可操纵的 AMM 价格
- [ ] 治理投票是否可通过闪电贷借入大量票权操控
- [ ] 清算逻辑是否可被闪电贷套利

### 7. 代理合约风险（Proxy Patterns）
- [ ] 存储槽冲突（Transparent Proxy / UUPS / Diamond 存储布局）
- [ ] 实现合约（Implementation）是否已初始化（防止自毁攻击）
- [ ] `delegatecall` 目标是否可信且不可篡改
- [ ] UUPS：`_authorizeUpgrade` 是否有足够权限保护
- [ ] Diamond：facet 函数选择器冲突检查
- [ ] 升级操作是否有时间锁保护

### 8. 经济模型 / 业务逻辑（Business Logic）
- [ ] 手续费计算是否可被绕过或操控
- [ ] 奖励分发机制是否存在重复领取
- [ ] 质押/解质押逻辑的竞态条件
- [ ] 通胀/通缩机制的极端情况
- [ ] 清算阈值和健康因子边界条件
- [ ] Rug Pull 风险（管理员是否可直接提走资金）

### 9. 签名 / 验证风险（Signature & Verification）
- [ ] 签名重放攻击（缺少 nonce 或 chainId）[SWC-121]
- [ ] ECDSA 签名可塑性（`ecrecover` 返回 `address(0)` 处理）
- [ ] EIP-712 结构化哈希实现正确性
- [ ] 批量操作签名验证逻辑

### 10. ERC 标准合规（Token Standards）
- [ ] ERC-20：`transfer` / `transferFrom` 返回值；`approve` 竞态（EIP-2612）
- [ ] ERC-20：Fee-on-transfer token 兼容性
- [ ] ERC-721：`safeTransferFrom` 接收方回调检查
- [ ] ERC-1155：批量操作中的整数溢出
- [ ] 元数据 URI 操控风险

### 11. 时间依赖（Timestamp & Block）[SWC-116]
- [ ] `block.timestamp` 用于随机数生成
- [ ] `block.timestamp` 可被矿工在 ±15 秒内操控
- [ ] 基于区块高度的时间估算误差

### 12. 中心化风险（Centralization）
- [ ] 单个 EOA 拥有 Owner 权限（建议多签）
- [ ] 管理员可暂停合约、冻结资金
- [ ] 升级权限集中（无治理 / 无时间锁）
- [ ] 关键参数（利率、手续费）可被管理员任意修改

### 13. DoS 风险（Denial of Service）[SWC-128]
- [ ] 无界循环（unbounded loop）导致 gas 耗尽
- [ ] 外部合约 `revert` 阻塞批量操作
- [ ] 强制发送 ETH（`selfdestruct` 攻击）[SWC-132]
- [ ] 存储数组无上限增长

### 14. 随机数（Randomness）[SWC-120]
- [ ] 使用链上随机数（`block.prevrandao` / `blockhash`）的风险
- [ ] 是否使用 Chainlink VRF 或等效方案

### 15. 前端运行 / MEV（Front-running & MEV）[SWC-114]
- [ ] 提交-揭示（Commit-Reveal）方案的需要
- [ ] 滑点保护（DEX 操作的 `minAmountOut`）
- [ ] 三明治攻击防护
- [ ] Flashbots / 私有 Mempool 建议

### 16. 跨链 / Bridge 风险
- [ ] 跨链消息重放（chainId 绑定）
- [ ] Bridge 消息伪造（签名验证）
- [ ] 资产映射的 1:1 锚定逻辑

---

## 风险等级标准

| 等级 | 描述 | 示例 |
|------|------|------|
| **Critical** | 直接导致资金损失或合约完全沦陷，无需特殊条件 | 重入 + 未更新状态、无权限 `withdraw` |
| **High** | 可导致重大资金损失，需特定条件（如闪电贷、管理员配合） | 预言机操纵、升级无保护 |
| **Medium** | 可导致合约行为异常或有限资金损失 | 精度损失、缺少事件日志 |
| **Low** | 最佳实践偏差，不直接危及安全 | `transfer` 代替 `call` 发 ETH |
| **Informational** | 代码质量、可读性、Gas 优化建议 | 变量命名、冗余代码 |

---

## 总体安全评分标准

| 评分 | 含义 |
|------|------|
| 90–100 | 优秀：无 Critical/High，少量 Medium |
| 75–89 | 良好：无 Critical，1–2 个 High |
| 60–74 | 一般：存在 High 级别问题，需修复后再部署 |
| 40–59 | 较差：存在 Critical 问题，禁止部署 |
| 0–39 | 危险：多个 Critical，合约设计存在根本性缺陷 |

扣分规则：每个 Critical -20 分，每个 High -10 分，每个 Medium -3 分，每个 Low -1 分，起始 100 分，最低 0 分。

---

## 报告模板

```markdown
# 智能合约安全审计报告

**合约名称**：{ContractName}
**合约地址**：{Address or "未部署"}
**审计日期**：{Date}
**审计工具**：My Expert DNA v1.0.0
**审计范围**：{文件列表}
**合约用途**：{简述}
**目标链**：{Chain}
**Solidity 版本**：{Version}

---

## ⚠️ 执行摘要

> {若存在 Critical 问题，在此用醒目警告标注}

{2–3 句总结：合约整体安全状况、主要风险点、建议行动}

**发现汇总**

| 等级 | 数量 |
|------|------|
| 🔴 Critical | {n} |
| 🟠 High | {n} |
| 🟡 Medium | {n} |
| 🟢 Low | {n} |
| ℹ️ Informational | {n} |

**总体安全评分：{score}/100**

---

## 详细发现

### 🔴 F-01：{漏洞标题} [Critical]

- **位置**：`{Contract.sol}:{行号}` — 函数 `{functionName}`
- **SWC 编号**：SWC-{编号}（如适用）
- **描述**：{详细说明漏洞成因、攻击路径}
- **攻击场景**：{步骤化的 PoC 描述，不含可直接执行的攻击代码}
- **影响**：{资金损失 / 合约瘫痪 / 权限劫持 等}
- **建议修复**：

```solidity
// ❌ 当前代码
{vulnerable code}

// ✅ 修复后代码
{fixed code}
```

---

## 总结与建议

1. **立即修复**（Critical / High）：{列出必须修复的问题}
2. **建议优化**（Medium / Low）：{列出建议改进的问题}
3. **部署前检查**：建议使用 Slither / Mythril 进行自动化扫描
4. **主网部署前**：建议委托专业第三方机构进行完整审计

---

*本报告由 My Expert DNA 生成，仅供参考，不构成安全保证。*
```

---

## 推荐配套工具

| 工具 | 用途 | 命令 |
|------|------|------|
| Slither | 静态分析（Python） | `slither . --checklist` |
| Mythril | 符号执行 | `myth analyze contract.sol` |
| Echidna | 模糊测试 | `echidna-test . --contract {Name}` |
| Foundry | 单元测试 + Fuzzing | `forge test --fuzz-runs 10000` |
| Hardhat | 本地部署测试 | `npx hardhat test` |
| 4naly3er | 静态检查报告 | `4naly3er src/` |

---

## 硬性约束

- **不得**承诺「此合约绝对安全」或「无漏洞」
- **不得**在报告中包含用户私钥、助记词等敏感数据
- **不得**自动执行任何链上操作（部署、调用合约）
- **不得**提供可直接用于攻击生产合约的完整 Exploit 代码
- 分析仅基于静态代码，运行时行为和经济模型边缘情况需进一步验证
- 若合约使用代理模式，须明确说明审计范围限于当前提供的实现合约版本
- 发现 Critical 级别问题时，**必须**在报告顶部用醒目警告标注，并建议暂停部署
